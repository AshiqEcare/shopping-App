import { Recipe } from "./../recipe.model";
import { Component, OnInit, Output, EventEmitter } from "@angular/core";

@Component({
  selector: "app-recipes-list",
  templateUrl: "./recipes-list.component.html",
  styleUrls: ["./recipes-list.component.scss"]
})
export class RecipesListComponent implements OnInit {
  @Output() recipeWasSelected = new EventEmitter<Recipe>();
  recipes: Recipe[] = [
    new Recipe(
      "Test Recipe",
      "A Test Recipe description",
      "https://cookieandkate.com/images/2019/10/best-red-chilaquiles-recipe-3.jpg"
    ),
    new Recipe(
      "Test Recipe 2",
      "A Test Recipe description 2",
      "https://cookieandkate.com/images/2019/10/best-red-chilaquiles-recipe-3.jpg"
    )
  ];

  constructor() {}

  ngOnInit() {}

  onRecipeSelected(recipe: Recipe) {
    this.recipeWasSelected.emit(recipe);
  }
}
